# Base

## Description

A Base template to use a 64bit environment from scratch.
A GUI and CL is provided to run the application.

## Table of Contents

- [Installation](#installation)

- [Usage](#usage)

- [Contributing](#contributing)

- [License](#license)

## Installation

Provide instructions on how to install and set up your project. Include any dependencies and prerequisites.

```bash
# Example installation steps
git clone https://github.com/golith/base.git
cd base
cmake .
cmake --build .
```

## Usage

## Contributing

## License
